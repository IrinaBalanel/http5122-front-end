// alert("Hello World!");
var myAge = 27;
var daysInYear = 365;
var total = myAge * daysInYear;
// alert(total);
var beginning = "I am ";
var end = " days old...more or less";
var completeSentense = beginning + total + end;
alert(completeSentense);