//LAB 3 - ARRAYS & LOOPS - PART 1


//ARRAY OF FRUITS
var fruits = ["Apple", "Pear", "Peach", "Orange", "Banana"];
var myFruit = fruits[0];
//OUTPUT ONE FRUIT FROM THE ARRAY IN POPUP BOX
var userInput = confirm;
alert("Here is my fruit: " + myFruit);
console.log (myFruit);